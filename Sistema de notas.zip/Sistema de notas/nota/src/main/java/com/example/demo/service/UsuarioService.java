package com.example.demo.service;

import com.example.demo.model.Usuario;

public interface UsuarioService extends ICrud<Usuario>{

}
