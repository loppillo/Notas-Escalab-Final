package com.example.demo.service;

import com.example.demo.model.Asistencia;


public interface AsistenciaService extends ICrud<Asistencia> {
	

}
