package com.example.demo.service;

import com.example.demo.model.Asignatura;

public interface AsignaturaService extends ICrud<Asignatura>{

}
