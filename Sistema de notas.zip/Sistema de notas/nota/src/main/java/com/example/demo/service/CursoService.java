package com.example.demo.service;

import com.example.demo.model.Curso;

public interface CursoService extends ICrud<Curso> {

}
